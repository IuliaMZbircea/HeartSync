<?php

namespace App\Controller;

use App\Entity\MedicalLetter;
use App\Repository\MedicalLetterRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

#[Route('/api/medical-letters')]
class MedicalLetterController extends AbstractController
{
    public function __construct(
        private EntityManagerInterface $em,
        private MedicalLetterRepository $medicalLetterRepository
    ) {}

    #[Route('', name: 'medical_letter_index', methods: ['GET'])]
    public function index(): JsonResponse
    {
        return $this->json($this->medicalLetterRepository->findAll());
    }

    #[Route('', name: 'medical_letter_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);
        if (!$data) {
            return $this->json(['error' => 'Invalid JSON'], Response::HTTP_BAD_REQUEST);
        }

        $medicalLetter = new MedicalLetter();
        $medicalLetter->setReferralId($data['referral_id']);
        $medicalLetter->setPatientId($data['patient_id']);
        $medicalLetter->setFromSpecialistId($data['from_specialist_id']);
        $medicalLetter->setToDoctorId($data['to_doctor_id']);
        $medicalLetter->setConsultationId($data['consultation_id'] ?? null);
        $medicalLetter->setDate(new \DateTime($data['date']));
        $medicalLetter->setFhirPayload($data['fhir_payload']);
        $medicalLetter->setStatus($data['status'] ?? 'active');
        $medicalLetter->setCreatedAt(new \DateTime());

        $this->em->persist($medicalLetter);
        $this->em->flush();

        return $this->json($medicalLetter, Response::HTTP_CREATED);
    }

    #[Route('/{id}', name: 'medical_letter_show', methods: ['GET'])]
    public function show(int $id): JsonResponse
    {
        $medicalLetter = $this->medicalLetterRepository->find($id);
        if (!$medicalLetter) {
            return $this->json(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }

        return $this->json($medicalLetter);
    }

    #[Route('/{id}', name: 'medical_letter_update', methods: ['PUT'])]
    public function update(Request $request, int $id): JsonResponse
    {
        $medicalLetter = $this->medicalLetterRepository->find($id);
        if (!$medicalLetter) {
            return $this->json(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode($request->getContent(), true);

        if (isset($data['referral_id'])) $medicalLetter->setReferralId($data['referral_id']);
        if (isset($data['patient_id'])) $medicalLetter->setPatientId($data['patient_id']);
        if (isset($data['from_specialist_id'])) $medicalLetter->setFromSpecialistId($data['from_specialist_id']);
        if (isset($data['to_doctor_id'])) $medicalLetter->setToDoctorId($data['to_doctor_id']);
        if (array_key_exists('consultation_id', $data)) $medicalLetter->setConsultationId($data['consultation_id']);
        if (isset($data['date'])) $medicalLetter->setDate(new \DateTime($data['date']));
        if (isset($data['fhir_payload'])) $medicalLetter->setFhirPayload($data['fhir_payload']);
        if (isset($data['status'])) $medicalLetter->setStatus($data['status']);

        $this->em->flush();
        return $this->json($medicalLetter);
    }

    #[Route('/{id}', name: 'medical_letter_delete', methods: ['DELETE'])]
    public function delete(int $id): JsonResponse
    {
        $medicalLetter = $this->medicalLetterRepository->find($id);
        if (!$medicalLetter) {
            return $this->json(['error' => 'Not found'], Response::HTTP_NOT_FOUND);
        }

        $this->em->remove($medicalLetter);
        $this->em->flush();

        return $this->json(['message' => 'Deleted']);
    }
}

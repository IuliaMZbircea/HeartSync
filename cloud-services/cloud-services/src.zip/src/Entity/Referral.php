<?php

namespace App\Entity;

use App\Repository\ReferralRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Metadata\ApiResource;

#[ApiResource]

#[ORM\Entity(repositoryClass: ReferralRepository::class)]
class Referral
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 50)]
    private ?string $type = null;

    #[ORM\Column]
    private ?int $patientId = null;

    #[ORM\Column]
    private ?int $fromDoctorId = null;

    #[ORM\Column(nullable: true)]
    private ?int $toDoctorId = null;

    #[ORM\Column(type: 'text')]
    private ?string $reason = null;

    #[ORM\Column(type: 'date')]
    private ?\DateTimeInterface $date = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $hl7Payload = null;

    #[ORM\Column(nullable: true)]
    private ?int $fhirResponseId = null;

    #[ORM\Column(type: 'boolean')]
    private ?bool $isResolved = false;

    #[ORM\Column(length: 50)]
    private ?string $status = 'active';

    #[ORM\Column(type: 'datetime')]
    private ?\DateTimeInterface $createdAt = null;

    // Getters & Setters

    public function getId(): ?int { return $this->id; }

    public function getType(): ?string { return $this->type; }
    public function setType(string $type): self { $this->type = $type; return $this; }

    public function getPatientId(): ?int { return $this->patientId; }
    public function setPatientId(int $patientId): self { $this->patientId = $patientId; return $this; }

    public function getFromDoctorId(): ?int { return $this->fromDoctorId; }
    public function setFromDoctorId(int $fromDoctorId): self { $this->fromDoctorId = $fromDoctorId; return $this; }

    public function getToDoctorId(): ?int { return $this->toDoctorId; }
    public function setToDoctorId(?int $toDoctorId): self { $this->toDoctorId = $toDoctorId; return $this; }

    public function getReason(): ?string { return $this->reason; }
    public function setReason(string $reason): self { $this->reason = $reason; return $this; }

    public function getDate(): ?\DateTimeInterface { return $this->date; }
    public function setDate(\DateTimeInterface $date): self { $this->date = $date; return $this; }

    public function getHl7Payload(): ?string { return $this->hl7Payload; }
    public function setHl7Payload(?string $hl7Payload): self { $this->hl7Payload = $hl7Payload; return $this; }

    public function getFhirResponseId(): ?int { return $this->fhirResponseId; }
    public function setFhirResponseId(?int $fhirResponseId): self { $this->fhirResponseId = $fhirResponseId; return $this; }

    public function isResolved(): ?bool { return $this->isResolved; }
    public function setIsResolved(bool $isResolved): self { $this->isResolved = $isResolved; return $this; }

    public function getStatus(): ?string { return $this->status; }
    public function setStatus(string $status): self { $this->status = $status; return $this; }

    public function getCreatedAt(): ?\DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }
}

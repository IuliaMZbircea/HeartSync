<?php

namespace App\Entity;

use App\Repository\MedicalLetterRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Metadata\ApiResource;

#[ApiResource]

#[ORM\Entity(repositoryClass: MedicalLetterRepository::class)]
class MedicalLetter
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $referralId = null;

    #[ORM\Column]
    private ?int $patientId = null;

    #[ORM\Column]
    private ?int $fromSpecialistId = null;

    #[ORM\Column]
    private ?int $toDoctorId = null;

    #[ORM\Column(nullable: true)]
    private ?int $consultationId = null;

    #[ORM\Column(type: 'date')]
    private ?\DateTimeInterface $date = null;

    #[ORM\Column(type: 'text')]
    private ?string $fhirPayload = null;

    #[ORM\Column(length: 50)]
    private ?string $status = 'active';

    #[ORM\Column(type: 'datetime')]
    private ?\DateTimeInterface $createdAt = null;

    public function getId(): ?int { return $this->id; }

    public function getReferralId(): ?int { return $this->referralId; }
    public function setReferralId(int $referralId): self { $this->referralId = $referralId; return $this; }

    public function getPatientId(): ?int { return $this->patientId; }
    public function setPatientId(int $patientId): self { $this->patientId = $patientId; return $this; }

    public function getFromSpecialistId(): ?int { return $this->fromSpecialistId; }
    public function setFromSpecialistId(int $fromSpecialistId): self { $this->fromSpecialistId = $fromSpecialistId; return $this; }

    public function getToDoctorId(): ?int { return $this->toDoctorId; }
    public function setToDoctorId(int $toDoctorId): self { $this->toDoctorId = $toDoctorId; return $this; }

    public function getConsultationId(): ?int { return $this->consultationId; }
    public function setConsultationId(?int $consultationId): self { $this->consultationId = $consultationId; return $this; }

    public function getDate(): ?\DateTimeInterface { return $this->date; }
    public function setDate(\DateTimeInterface $date): self { $this->date = $date; return $this; }

    public function getFhirPayload(): ?string { return $this->fhirPayload; }
    public function setFhirPayload(string $fhirPayload): self { $this->fhirPayload = $fhirPayload; return $this; }

    public function getStatus(): ?string { return $this->status; }
    public function setStatus(string $status): self { $this->status = $status; return $this; }

    public function getCreatedAt(): ?\DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }
}
